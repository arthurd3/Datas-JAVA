import java.time.LocalDateTime;

public class Datas {
    private int dia, mes, ano;
    private LocalDateTime dataAtual;

    // Construtor vazio
    public Datas() {
        dataAtual = LocalDateTime.now();
        this.dia = dataAtual.getDayOfMonth();
        this.mes = dataAtual.getMonthValue();
        this.ano = dataAtual.getYear();
    }

    // Construtor com parâmetros
    public Datas(int dia, int mes, int ano) {
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
        dataAtual = LocalDateTime.now();
    }

    // Getters e Setters
    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getDia() {
        return dia;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getMes() {
        return mes;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public int getAno() {
        return ano;
    }

   
    public void mostrarData() {
        System.out.println("Dia/mes/ano : " + getDia() + "/" + getMes() + "/" + getAno());
        System.out.println("Data Atual : " + dataAtual.getDayOfMonth() + "/" + dataAtual.getMonthValue() + "/" + dataAtual.getYear());
    }

 
    public void pularDias(int diaskip) {
        int[] diasPorMes = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

       
        if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0)) {
            diasPorMes[1] = 29; 
        }

        dia += diaskip;

        while (dia > diasPorMes[mes - 1]) {
            dia -= diasPorMes[mes - 1];
            mes++;

            if (mes > 12) {
                mes = 1; 
                ano++;   
            }
        }

        System.out.println("Nova data: " + dia + "/" + mes + "/" + ano);
    }
}
