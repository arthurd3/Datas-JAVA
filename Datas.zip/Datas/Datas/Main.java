import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner le = new Scanner(System.in);
        Datas calendario1 = new Datas();
        calendario1.setDia(10);
        calendario1.setMes(10);
        calendario1.setAno(1980);
        calendario1.mostrarData();
        
        int a = 1;
        while(a > 0){
            System.out.println("Pular Quantos Dias? : ");
            int diaskip = le.nextInt();
            calendario1.pularDias(diaskip);
        
        }
   
    }
}